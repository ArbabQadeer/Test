  function openNav() {
          document.getElementById("sidebar").style.left = "0px";
        }  
        function closeNav() {
          document.getElementById("sidebar").style.left = "-100vw"; 
          }

//            function handleMousePos(event) {
//       var mouseClickWidth = event.clientX;
//       if(mouseClickWidth>=280){
//             document.getElementById("mySidebar").style.left = "-100vw";
//             document.getElementById("sidebar_container_blur_bg").style.right = "-105vw";
//            }
// }

// document.addEventListener("click", handleMousePos);









